<?php

return [
    'EvilBot',
];
